# Documentación de mi primer paquete

1. crear README.md
2. crear LICENSE.txt
   1. entrar en [esta página](https://choosealicense.com/)
   2. elegir una licencia (por ejemplo [MIT License](https://choosealicense.com/licenses/mit/))
   3. copiarla y pegarla en LICENSE.txt
3. crear setup.py